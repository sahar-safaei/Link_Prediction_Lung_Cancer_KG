'''Downloads SNLI data and wrangles it into the spoder format'''


if __name__ == '__main__':
    snli2spoder()
